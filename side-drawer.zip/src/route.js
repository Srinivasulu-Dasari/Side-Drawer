
import Home from './Components/Pages/Home';
import Profile from './Components/Pages/Profile';
import Settings from './Components/Pages/Settings';
import Welcome from './Components/Pages/Welcome';

const routes = [
    { path: '/home', component: Home },
    { path: '/profile', component: Profile },
    { path: '/settings', component: Settings },

    { path: '/', component: Welcome }

];

export default routes;
