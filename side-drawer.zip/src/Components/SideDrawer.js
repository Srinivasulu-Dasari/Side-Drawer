import React, { Component } from 'react';
import {
    HashRouter as Router,
    Switch,
    Route,
    NavLink
} from "react-router-dom";

class SideDrawer extends Component {

    openNav() {
        document.getElementById("mySidenav").style.width = "250px";
    }

    closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }

    render() {
        return (
            <div>
                <Router>
                    <div id="mySidenav" className="sidenav">
                        <a href="javascript:void(0)" className="closebtn" onClick={this.closeNav}>&times;</a>
                        <a><NavLink to="/home" activeClassName="navActive">Home</NavLink></a>
                        <a><NavLink to="/profile" activeClassName="navActive">Profile</NavLink></a>
                        <a><NavLink to="/settings" activeClassName="navActive">Settings</NavLink></a>
                    </div>
                </Router>
                <span style={{ fontSize: '30px', cursor: 'pointer' }} className="sideDrawerIcon" onClick={this.openNav}>&#9776;</span>
            </div>
        )
    }
}

export default SideDrawer;
