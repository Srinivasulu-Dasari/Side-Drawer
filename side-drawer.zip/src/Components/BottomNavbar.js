import React, { Component } from 'react';
import {
    HashRouter as Router,
    NavLink
} from "react-router-dom";


class BottomNavbar extends Component {
    render() {
        return (
            <div className="bottomNavBar">
                <Router>
                    <ul className="ul">
                        <li><NavLink to="/home" activeClassName="navActive">Home</NavLink></li>
                        <li><NavLink to="/profile" activeClassName="navActive">Profile</NavLink></li>
                        <li><NavLink to="/settings" activeClassName="navActive">Settings</NavLink></li>
                    </ul>
                </Router>
            </div>
        )
    }
}

export default BottomNavbar;
