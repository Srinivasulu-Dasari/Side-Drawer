import React, { Component } from 'react';
import SideDrawer from '../Components/SideDrawer';
import BottomNavbar from '../Components/BottomNavbar';

export class Layout extends Component {

    constructor(props) {
        super(props);

    }

    render() {
        return (
            <React.Fragment>
                <SideDrawer />
                <BottomNavbar />
                <div className="contentDisplayArea">
                    {this.props.children}
                </div>
            </React.Fragment>
        )
    }
}

export default Layout;
