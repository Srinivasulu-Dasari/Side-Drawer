import React, { Component } from 'react'

export class Settings extends Component {
    render() {
        return (
            <div>
                Settings Page
            </div>
        )
    }
}

export default Settings;
