import React, { Component } from 'react'

export class Profile extends Component {
    render() {
        return (
            <div>
                Profile Page
            </div>
        )
    }
}

export default Profile;
