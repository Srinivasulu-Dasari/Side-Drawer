import React from 'react';
import './App.css';
import { Route, Switch, HashRouter as Router } from 'react-router-dom';
import Layout from './Components/Layout';
import routes from './route';

function withLayout(WrappedComponent) {
  return class extends React.Component {
    render() {
      return (
        <Layout>
          <WrappedComponent></WrappedComponent>
        </Layout>
      )
    }
  };
}

function App() {
  return (
    <div className="App">
      <Router >
        <Switch>
          {routes.map((route, idx) =>
            <Route path={route.path} exact component={withLayout(route.component)} key={idx} />
          )}
        </Switch>
      </Router>
    </div>
  );
}

export default App;
